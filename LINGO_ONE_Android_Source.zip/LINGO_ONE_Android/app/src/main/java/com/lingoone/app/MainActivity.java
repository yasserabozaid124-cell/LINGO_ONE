package com.lingoone.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int MIC_REQ = 42;
    private boolean reverse = false;
    private EditText input;
    private TextView output, status, from, to;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,20,38));
        getWindow().setNavigationBarColor(Color.rgb(5,20,38));
        buildUi();
        tts = new TextToSpeech(this, result -> { });
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView label(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE);
        t.setTextSize(size); t.setGravity(Gravity.CENTER); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0,125,220)));
        return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(1);
        page.setPadding(dp(20),dp(28),dp(20),dp(24));
        page.setBackgroundColor(Color.rgb(5,20,38));
        scroll.addView(page); setContentView(scroll);

        TextView title = label("LINGO ONE", 30); title.setTypeface(null, 1);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));
        TextView sub = label("مترجم المحادثات الصوتية", 16);
        sub.setTextColor(Color.rgb(160,205,225)); page.addView(sub);

        LinearLayout langs = new LinearLayout(this); langs.setGravity(Gravity.CENTER); langs.setPadding(0,dp(22),0,dp(14));
        from = label("العربية 🇪🇬",18); to = label("English 🇬🇧",18);
        langs.addView(from,new LinearLayout.LayoutParams(0,dp(55),1));
        Button swap = button("⇄"); langs.addView(swap,new LinearLayout.LayoutParams(dp(58),dp(55)));
        langs.addView(to,new LinearLayout.LayoutParams(0,dp(55),1)); page.addView(langs);
        swap.setOnClickListener(v -> { reverse=!reverse; updateLangs(); });

        status = label("جاهز — اضغط الميكروفون وابدأ الكلام",14);
        status.setTextColor(Color.rgb(45,215,240)); page.addView(status,new LinearLayout.LayoutParams(-1,dp(48)));

        Button mic = button("🎙  تسجيل الصوت");
        page.addView(mic,new LinearLayout.LayoutParams(-1,dp(62)));
        mic.setOnClickListener(v -> startListening());

        TextView inTitle = label("النص الأصلي",16); page.addView(inTitle,new LinearLayout.LayoutParams(-1,dp(42)));
        input = new EditText(this); input.setTextColor(Color.WHITE); input.setHintTextColor(Color.GRAY);
        input.setHint("تحدث أو اكتب هنا…"); input.setGravity(Gravity.TOP|Gravity.RIGHT);
        input.setMinLines(3); input.setBackgroundColor(Color.rgb(15,43,67)); page.addView(input,new LinearLayout.LayoutParams(-1,dp(125)));

        Button translate = button("ترجم النص"); page.addView(translate,new LinearLayout.LayoutParams(-1,dp(58)));
        translate.setOnClickListener(v -> translateText());

        TextView outTitle = label("الترجمة",16); page.addView(outTitle,new LinearLayout.LayoutParams(-1,dp(42)));
        output = label("ستظهر الترجمة هنا",18); output.setBackgroundColor(Color.rgb(15,43,67));
        output.setPadding(dp(12),dp(12),dp(12),dp(12)); page.addView(output,new LinearLayout.LayoutParams(-1,dp(120)));

        Button speak = button("🔊 استمع للترجمة"); page.addView(speak,new LinearLayout.LayoutParams(-1,dp(58)));
        speak.setOnClickListener(v -> speakTranslation());
        TextView note = label("نسخة أولية تحتاج إنترنت. لا تستخدمها للمحادثات الحساسة. الترجمة عبر خدمة تجريبية وقد تخطئ.",12);
        note.setTextColor(Color.LTGRAY); page.addView(note,new LinearLayout.LayoutParams(-1,dp(70)));
    }

    private void updateLangs() {
        from.setText(reverse ? "English 🇬🇧" : "العربية 🇪🇬");
        to.setText(reverse ? "العربية 🇪🇬" : "English 🇬🇧");
        input.setHint(reverse ? "Type or speak in English…" : "تحدث أو اكتب بالعربية…");
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("التعرف على الصوت غير متاح على هذا الجهاز."); return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ); return;
        }
        launchRecognizer();
    }
    private void launchRecognizer() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, reverse ? "en-US" : "ar-EG");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, reverse ? "Speak English" : "تحدث بالعربية");
            startActivityForResult(i, MIC_REQ);
        } catch (Exception e) { status.setText("تعذر تشغيل الميكروفون: " + e.getMessage()); }
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r==MIC_REQ && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) launchRecognizer();
        else status.setText("لم يتم السماح باستخدام الميكروفون.");
    }
    @Override protected void onActivityResult(int r,int c,Intent data) {
        super.onActivityResult(r,c,data);
        if (r==MIC_REQ && c==RESULT_OK && data!=null) {
            ArrayList<String> results=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(results!=null && !results.isEmpty()) { input.setText(results.get(0)); status.setText("تم التقاط الكلام. اضغط ترجم النص."); }
        } else if(r==MIC_REQ) status.setText("لم يتم التقاط الكلام. حاول مرة أخرى.");
    }

    private void translateText() {
        String q=input.getText().toString().trim();
        if(q.isEmpty()){status.setText("اكتب النص أو سجّل صوتك أولًا.");return;}
        status.setText("جارٍ الترجمة…");
        new Thread(() -> {
            HttpURLConnection conn=null;
            try {
                String pair=reverse?"en|ar":"ar|en";
                String url="https://api.mymemory.translated.net/get?q="+URLEncoder.encode(q,"UTF-8")+"&langpair="+pair;
                conn=(HttpURLConnection)new URL(url).openConnection(); conn.setConnectTimeout(12000); conn.setReadTimeout(12000);
                String body=new String(conn.getInputStream().readAllBytes(),"UTF-8");
                String translated=new JSONObject(body).getJSONObject("responseData").getString("translatedText");
                runOnUiThread(() -> {output.setText(translated);status.setText("اكتملت الترجمة التجريبية.");});
            } catch(Exception e){runOnUiThread(() -> {output.setText("تعذر الاتصال بخدمة الترجمة. تحقق من الإنترنت.");status.setText("فشلت الترجمة، حاول لاحقًا.");});}
            finally {if(conn!=null)conn.disconnect();}
        }).start();
    }
    private void speakTranslation() {
        String s=output.getText().toString();
        if(s.isEmpty() || s.equals("ستظهر الترجمة هنا")) return;
        if(tts!=null){tts.setLanguage(reverse?new Locale("ar"):Locale.US);tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"lingo_translation");}
    }
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
